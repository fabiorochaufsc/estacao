#ifndef _DS18B20_
#define _DS18B20_

 
float DS18B20_Captura_temperatura(void);

#endif
